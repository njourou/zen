document.addEventListener('DOMContentLoaded', function () {
    var episodeLinks = document.querySelectorAll('#episode-list a');
    episodeLinks.forEach(function (link) {
      link.addEventListener('click', function (event) {
        event.preventDefault();
        var episodeNumber = this.getAttribute('data-episode-number');
        var season = this.getAttribute('data-season');
        var episodeUrl = "https://vidsrc.to/embed/tv/<?php echo $selected_series; ?>/" + season + "/" + episodeNumber;
        document.getElementById('video-player').src = episodeUrl;
      });
    });
  });

  document.addEventListener('DOMContentLoaded', function () {
    var seasonForm = document.getElementById('season-form');
    var episodeList = document.getElementById('episode-list');
    var videoPlayer = document.getElementById('video-player');

    seasonForm.addEventListener('change', function () {
      var selectedSeason = this.querySelector('#season').value;
      var selectedSeries = this.querySelector('input[name="series_id"]').value;

      fetchEpisodes(selectedSeries, selectedSeason);
    });

    function fetchEpisodes(seriesId, seasonNumber) {
      var url = "https://api.themoviedb.org/3/tv/" + seriesId + "/season/" + seasonNumber + "?api_key=21e8c70b8d8ab44e9ce6e7d707eb4a9f";
      
      fetch(url)
        .then(function(response) {
          return response.json();
        })
        .then(function(data) {
          episodeList.innerHTML = ''; // Clear existing episodes

          if (data.episodes && data.episodes.length > 0) {
            data.episodes.forEach(function(episode) {
              var episodeNumber = episode.episode_number;
              var episodeName = episode.name;
              var listItem = document.createElement('li');
              var link = document.createElement('a');
              link.href = "https://vidsrc.to/embed/tv/" + seriesId + "/" + seasonNumber + "/" + episodeNumber;
              link.textContent = episodeName;
              link.addEventListener('click', function(event) {
                event.preventDefault();
                var episodeUrl = this.href;
                videoPlayer.src = episodeUrl;
              });
              listItem.appendChild(link);
              episodeList.appendChild(listItem);
            });
          } else {
            episodeList.innerHTML = "<p>No episodes available.</p>";
          }
        })
        .catch(function(error) {
          console.error('Error fetching episodes:', error);
        });
    }

    // Automatically play the video when the source changes
    videoPlayer.addEventListener('load', function () {
      videoPlayer.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
    });

    // Initial fetch of episodes
    var selectedSeason = document.querySelector('#season').value;
    var selectedSeries = document.querySelector('input[name="series_id"]').value;
    fetchEpisodes(selectedSeries, selectedSeason);
  });

