<?php
include "./includes/header.php";?>

<?php
function displayTVSeries($tv_series) {
    if($tv_series) {
        echo "<h2>TV Series</h2>";
        echo "<div class='row'>";
        foreach ($tv_series as $series) {
            $title = isset($series['original_name']) ? $series['original_name'] : $series['name']; // Use original_name for TV series
            $poster_path = $series['poster_path'];
            $poster_url = "https://image.tmdb.org/t/p/w500{$poster_path}";
            $year_released = substr($series['first_air_date'], 0, 4); // Extracting year from first_air_date
            $rating = $series['vote_average']; // Rating of the TV series

            echo "<div class='col-lg-3 col-md-6 d-flex align-items-stretch'>";
            echo "<div class='member' data-aos='fade-up' data-aos-delay='100'>";
            echo "<div class='member-img'>";
            echo "<a href='video.php?series_id={$series['id']}'>";
            echo "<img src='{$poster_url}' class='img-fluid' alt='{$title}'>";
            echo "</a>";
            echo "<div class='social'>";
            echo "<a href='video.php?series_id={$series['id']}'>";
            echo "</div>";
            echo "</div>";
            echo "<div class='member-info'>";
            echo "<h4>{$title}</h4>";
            echo "<span>{$year_released}</span>";
            echo "<p>Rating: {$rating}</p>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>No TV series found!</p>";
    }
}

if(isset($_GET['query'])) {
    $search_query = $_GET['query'];
    $search_query = urlencode($search_query);
    $api_key = '21e8c70b8d8ab44e9ce6e7d707eb4a9f'; // Replace 'YOUR_API_KEY' with your actual API key

    // Construct the API URL for searching TV series
    $url_tv_series = "https://api.themoviedb.org/3/search/tv?api_key={$api_key}&query={$search_query}";

    // Construct the API URL for searching movies
    $url_movies = "https://api.themoviedb.org/3/search/movie?api_key={$api_key}&query={$search_query}";

    // Perform the API request for TV series
    $response_tv_series = file_get_contents($url_tv_series);

    // Perform the API request for movies
    $response_movies = file_get_contents($url_movies);

    // Check if requests were successful
    if($response_tv_series === false || $response_movies === false) {
        echo "Error fetching search results.";
    } else {
        // Decode the JSON response for TV series
        $data_tv_series = json_decode($response_tv_series, true);
        // Decode the JSON response for movies
        $data_movies = json_decode($response_movies, true);

        // Extract TV series and movies results
        $tv_series = $data_tv_series['results'];
        $movies = $data_movies['results'];

        // Display TV series and movies
        echo "<section id='team' class='team section-bg'>";
        echo "<div class='container' data-aos='fade-up'>";
        echo "<div class='row'>";
        displayTVSeries($tv_series);
        echo "</div>";
        echo "</div>";
        echo "</section>";
    }
} else {
    echo "No search query provided.";
}
?>
<?php
include "./includes/footer.php";
?>